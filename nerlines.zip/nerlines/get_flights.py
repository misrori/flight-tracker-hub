import requests
import json
import os
import time
import csv
from datetime import datetime, timedelta
# --- KONFIGURÁCIÓ ---


aircraft_config_json = """
[
  {
    "HEX kód": "440392",
    "Lajstromjel": "OE-IAV",
    "Típus": "Bombardier BD-700-2A12 Global 7500",
    "Kategória": "ultra nagy hatótávolságú business jet",
    "Gyártási év": "2023",
    "Kötődés": "Szijj László",
    "Magyar kötődés kezdete": "2025. 05. 08.",
    "Magyar kötődés vége": "-",
    "Újonnani érték": "27,5 milliárd Ft",
    "Üzemeltetési költség/óra": "9500 USD",
    "Cikk(ek)": "1"
  },
  {
    "HEX kód": "440241",
    "Lajstromjel": "OE-LOT",
    "Típus": "Bombardier BD-700-1A10 Global 6500",
    "Kategória": "nagy hatótávolságú business jet",
    "Gyártási év": "2024",
    "Kötődés": "Mészáros Lőrinc",
    "Magyar kötődés kezdete": "2024. 09. 07.",
    "Magyar kötődés vége": "-",
    "Újonnani érték": "22 milliárd Ft",
    "Üzemeltetési költség/óra": "9900 USD",
    "Cikk(ek)": "1, 2"
  },
  {
    "HEX kód": "440B18",
    "Lajstromjel": "OE-XWY",
    "Típus": "Agusta Westland AW-109 Grand",
    "Kategória": "könnyű, kéthajtóműves helikopter",
    "Gyártási év": "2019",
    "Kötődés": "Mészáros Lőrinc",
    "Magyar kötődés kezdete": "2021. 03. 11.",
    "Magyar kötődés vége": "-",
    "Újonnani érték": "1,8 milliárd Ft",
    "Üzemeltetési költség/óra": "3800 USD",
    "Cikk(ek)": "1"
  },
  {
    "HEX kód": "440603",
    "Lajstromjel": "OE-IMB",
    "Típus": "Bombardier BD-700-1A10 Global 6000",
    "Kategória": "nagy hatótávolságú business jet",
    "Gyártási év": "2018",
    "Kötődés": "Szíjj László",
    "Magyar kötődés kezdete": "2022. 08. 03.",
    "Magyar kötődés vége": "2025. 03. 01.",
    "Újonnani érték": "17 milliárd Ft",
    "Üzemeltetési költség/óra": "10600 USD",
    "Cikk(ek)": "1"
  },
  {
    "HEX kód": "4401D7",
    "Lajstromjel": "OE-LEM",
    "Típus": "Bombardier BD-700-1A10 Global 6000",
    "Kategória": "nagy hatótávolságú business jet",
    "Gyártási év": "2017",
    "Kötődés": "Mészáros Lőrinc, Szíjj László",
    "Magyar kötődés kezdete": "2018. 05. 01.",
    "Magyar kötődés vége": "2023. 10. 07.",
    "Újonnani érték": "16,5 milliárd Ft",
    "Üzemeltetési költség/óra": "10600 USD",
    "Cikk(ek)": "1, 2"
  },
  {
    "HEX kód": "440D18",
    "Lajstromjel": "OE-HUG",
    "Típus": "Bombardier BD-100-1A-10 Challenger 350",
    "Kategória": "felső-középkategóriás business jet",
    "Gyártási év": "2014",
    "Kötődés": "Mészáros Lőrinc, Kalocsai László",
    "Magyar kötődés kezdete": "2023. 02. 01.",
    "Magyar kötődés vége": "2025. 06. 23.",
    "Újonnani érték": "7 milliárd Ft",
    "Üzemeltetési költség/óra": "6500 USD",
    "Cikk(ek)": "1"
  },
  {
    "HEX kód": "440214",
    "Lajstromjel": "OE-HOZ",
    "Típus": "Bombardier BD-100-1A-10 Challenger 3500",
    "Kategória": "felső-középkategóriás business jet",
    "Gyártási év": "2024",
    "Kötődés": "Mészáros Lőrinc",
    "Magyar kötődés kezdete": "2024. 07. 10.",
    "Magyar kötődés vége": "-",
    "Újonnani érték": "9,6 milliárd Ft",
    "Üzemeltetési költség/óra": "6970 USD",
    "Cikk(ek)": "1"
  },
  {
    "HEX kód": "471E26",
    "Lajstromjel": "HA-LKW",
    "Típus": "Dassault Falcon 8X",
    "Kategória": "ultra nagy hatótávolságú business jet",
    "Gyártási év": "2021",
    "Kötődés": "Air Invest Kft./OTP Bank Nyrt.",
    "Magyar kötődés kezdete": "2021. 06. 25.",
    "Magyar kötődés vége": "-",
    "Újonnani érték": "17 milliárd Ft",
    "Üzemeltetési költség/óra": "9300 USD",
    "Cikk(ek)": "1"
  },
  {
    "HEX kód": "471E29",
    "Lajstromjel": "HA-LKZ",
    "Típus": "Dassault Falcon 900LX",
    "Kategória": "nagy hatótávolságú business jet",
    "Gyártási év": "2017",
    "Kötődés": "Air Invest Kft./OTP Bank Nyrt.",
    "Magyar kötődés kezdete": "2017. 12. 14.",
    "Magyar kötődés vége": "-",
    "Újonnani érték": "11 milliárd Ft",
    "Üzemeltetési költség/óra": "7190 USD",
    "Cikk(ek)": "1"
  },
  {
    "HEX kód": "47031E",
    "Lajstromjel": "HA-BES",
    "Típus": "Raytheon Hawker 800XPi",
    "Kategória": "közepes méretű business jet",
    "Gyártási év": "2005",
    "Kötődés": "Bessenyei István/Valton-Sec ",
    "Magyar kötődés kezdete": "2017. 12. 22.",
    "Magyar kötődés vége": "-",
    "Újonnani érték": "2,5 milliárd Ft",
    "Üzemeltetési költség/óra": "5900 USD",
    "Cikkek": "1, 2, 3"
  },
  {
    "HEX kód": "4727D8",
    "Lajstromjel": "HA-BES",
    "Típus": "Raytheon Hawker 800XPi",
    "Kategória": "közepes méretű business jet",
    "Gyártási év": "2005",
    "Kötődés": "Nagy Elek/BÁV Zrt.",
    "Magyar kötődés kezdete": "2017. 12. 22.",
    "Magyar kötődés vége": "-",
    "Újonnani érték": "2,5 milliárd Ft",
    "Üzemeltetési költség/óra": "5900 USD",
    "Cikkek": "1, 2, 3"
  },
  {
    "HEX kód": "49D5A8",
    "Lajstromjel": "OK-BIF",
    "Típus": "Pilatus PC-12/47E NGX",
    "Kategória": "egymotoros, turbólégcsavaros repülőgép",
    "Gyártási év": "2024",
    "Kötődés": "BIF Zrt./Schmidt Mária és gyermekei",
    "Magyar kötődés kezdete": "2024. 07. 02.",
    "Magyar kötődés vége": "-",
    "Újonnani érték": "2 milliárd Ft",
    "Üzemeltetési költség/óra": "2600 USD",
    "Cikk(ek)": "1"
  }
]
"""




aircraft_list = json.loads(aircraft_config_json)
aircraft_list


ROOT_DIR = "/home/misi/nerlines/data/"  # Fő mappa
START_DATE = datetime(2023, 1, 10) # Kezdő dátum fixálva

HEADERS = {
    'sec-ch-ua-platform': '"macOS"',
    'X-Requested-With': 'XMLHttpRequest',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
}

# --- FÜGGVÉNYEK ---

def load_processed_dates(csv_path):
    """Beolvassa a már ellenőrzött dátumokat a CSV-ből."""
    processed = set()
    if os.path.exists(csv_path):
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            next(reader, None)  # Header átugrása
            for row in reader:
                if row:
                    processed.add(row[0]) # Az első oszlop a dátum (YYYY-MM-DD)
    return processed

def update_log(csv_path, date_str, status, filename="-"):
    """Hozzáad egy sort a státusz táblázathoz."""
    file_exists = os.path.exists(csv_path)
    with open(csv_path, 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["Datum", "Status", "Fajlnev"]) # Fejléc
        writer.writerow([date_str, status, filename])

# --- FŐ PROGRAM ---

aircraft_list = json.loads(aircraft_config_json)
today = datetime.now()

if not os.path.exists(ROOT_DIR):
    os.makedirs(ROOT_DIR)

print(f"--- Adatgyűjtés indítása: {START_DATE.strftime('%Y-%m-%d')} -> {today.strftime('%Y-%m-%d')} ---\n")

for aircraft in aircraft_list:
    # Kezeljük, ha több HEX kód van egy mezőben (vesszővel elválasztva)
    hex_codes = [h.strip() for h in aircraft['HEX kód'].split(',')]
    
    for icao in hex_codes:
        reg = aircraft.get('Lajstromjel', 'Unknown')
        
        # Mappa létrehozása a HEX kód alapján
        aircraft_dir = os.path.join(ROOT_DIR, icao)
        if not os.path.exists(aircraft_dir):
            os.makedirs(aircraft_dir)
            
        # Log fájl útvonala
        log_path = os.path.join(aircraft_dir, "status_log.csv")
        
        # Már feldolgozott napok betöltése a táblázatból
        processed_dates = load_processed_dates(log_path)
        
        print(f"\n>>> Feldolgozás: {icao} ({reg})")
        
        current_date = START_DATE
        
        while current_date <= today:
            date_str_iso = current_date.strftime("%Y-%m-%d") # Loghoz: 2024-01-01
            
            # URL-hez szükséges formátumok
            yyyy = current_date.strftime("%Y")
            mm = current_date.strftime("%m")
            dd = current_date.strftime("%d")
            
            # Fájlnév: HEX_YYYY_MM_DD.json
            filename_json = f"{icao}_{yyyy}_{mm}_{dd}.json"
            filepath_json = os.path.join(aircraft_dir, filename_json)
            
            # 1. ELLENŐRZÉS: Volt-e már ez a nap csekkolva?
            if date_str_iso in processed_dates:
                # print(f"  [SKIP] Már ellenőrizve: {date_str_iso}")
                current_date += timedelta(days=1)
                continue
                
            # URL összeállítása
            last_two = icao[-2:]
            url = f"https://globe.adsbexchange.com/globe_history/{yyyy}/{mm}/{dd}/traces/{last_two}/trace_full_{icao}.json"
            
            req_headers = HEADERS.copy()
            req_headers['Referer'] = f'https://globe.adsbexchange.com/?icao={icao}'
            
            try:
                print(f"  Lekérdezés: {date_str_iso} ...", end=" ", flush=True)
                response = requests.get(url, headers=req_headers, timeout=10)
                
                status_to_log = "ERROR"
                file_saved = "-"
                
                if response.status_code == 200:
                    try:
                        data = response.json()
                        # Ellenőrizzük, hogy van-e benne érdemi 'trace' adat
                        if 'trace' in data and data['trace']:
                            with open(filepath_json, 'w', encoding='utf-8') as f:
                                json.dump(data, f)
                            print("[OK - REPÜLT]")
                            status_to_log = "REPULT"
                            file_saved = filename_json
                        else:
                            print("[OK - ÜRES]")
                            status_to_log = "NINCS_ADAT" # 200 OK, de üres JSON
                    except json.JSONDecodeError:
                        print("[JSON ERROR]")
                        status_to_log = "JSON_HIBA"
                        
                elif response.status_code == 404:
                    print("[404 - NEM REPÜLT]")
                    status_to_log = "NEM_REPULT"
                else:
                    print(f"[HTTP {response.status_code}]")
                    status_to_log = f"HTTP_{response.status_code}"

                # Frissítjük a táblázatot (CSV)
                update_log(log_path, date_str_iso, status_to_log, file_saved)
                
                # Hozzáadjuk a memóriában lévő listához is, hogy ne kérdezze le újra, ha nem lépünk ki a ciklusból
                processed_dates.add(date_str_iso)

            except Exception as e:
                print(f"[EXCEPTION] {e}")
            
            # Késleltetés, hogy ne tiltsanak ki
            time.sleep(1.2)
            current_date += timedelta(days=1)

print("\n--- KÉSZ ---")