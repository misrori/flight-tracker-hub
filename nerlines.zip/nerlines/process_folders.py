import json
import pandas as pd
import glob
import os
from datetime import datetime

class FlightProcessor:
    def __init__(self, input_folder='data'):
        self.input_folder = input_folder
        self.detailed_flights = [] # Ez megy a JSON-be (útvonallal)
        self.summary_flights = []  # Ez megy a CSV táblázatba (útvonal nélkül)

    def get_file_groups(self):
        """
        Csoportosítja a fájlokat a repülőgép ID-ja alapján.
        Visszatér: {'ID1': ['fajl1.json', 'fajl2.json'], ...}
        """
        file_pattern = os.path.join(self.input_folder, '*.json')
        all_files = glob.glob(file_pattern)

        groups = {}
        for file_path in all_files:
            filename = os.path.basename(file_path)
            # Feltételezzük: ID_DATUM.json formátum
            if '_' in filename:
                aircraft_id = filename.split('_')[0]
                if aircraft_id not in groups:
                    groups[aircraft_id] = []
                groups[aircraft_id].append(file_path)
        return groups

    def process_all(self):
        """
        A fő vezérlő: ID-nként halad, időrendbe rakja a fájlokat,
        összefűzi a pontokat, majd futtatja a repülés-detektálást.
        """
        file_groups = self.get_file_groups()
        print(f"Talált egyedi repülőgépek száma: {len(file_groups)}")

        # Végigmegyünk az egyes gépeken
        for aircraft_id, files in file_groups.items():
            print(f"--- Feldolgozás: {aircraft_id} ({len(files)} fájl) ---")

            # 1. Fájlok időrendbe rakása (nagyon fontos a folytonosság miatt!)
            files.sort()

            # 2. Az adott gép összes adatpontjának betöltése egyetlen nagy listába
            # Ez biztosítja, hogy az éjféli átnyúlásokat észrevegyük.
            aircraft_all_points = []
            for file_path in files:
                aircraft_all_points.extend(self.load_single_file(file_path))

            # 3. Repülések keresése az összefűzött adatokban
            if aircraft_all_points:
                self.detect_flights(aircraft_all_points)

    def load_single_file(self, file_path):
        """Egy JSON fájl betöltése és a pontok formázása."""
        points = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

                meta = {
                    'icao': data.get('icao'),
                    'registration': data.get('r'),
                    'type_code': data.get('t'),
                    'operator': data.get('ownOp')
                }
                base_ts = data.get('timestamp', 0)
                traces = data.get('trace', [])

                for p in traces:
                    if len(p) < 4: continue
                    # Adatstruktúra: [ts_offset, lat, lon, alt, speed, ...]
                    point = {
                        'ts': base_ts + p[0],
                        'lat': p[1],
                        'lon': p[2],
                        'alt': p[3], # Lehet "ground" string vagy szám
                        'spd': p[4] if len(p) > 4 else 0
                    }
                    point.update(meta)
                    points.append(point)
        except Exception as e:
            print(f"Hiba a fájl olvasásakor ({file_path}): {e}")
        return points

    def detect_flights(self, points_list):
        """
        A 'state machine', ami eldönti, mikor van levegőben a gép.
        """
        # Pandas DataFrame a kényelmes rendezéshez és iteráláshoz
        df = pd.DataFrame(points_list)
        df = df.sort_values('ts').reset_index(drop=True)

        if df.empty: return

        # Metaadatok az első sorból
        first_row = df.iloc[0]
        meta = {
            'id': first_row['icao'],
            'reg': first_row['registration'],
            'type': first_row['type_code'],
            'op': first_row['operator']
        }

        current_flight_points = []
        is_in_air = False

        # Segédfüggvény: levegőben vagyunk?
        def check_is_air(alt_val):
            if str(alt_val).lower() == 'ground': return False
            try:
                # Opcionális: 50 láb alatt földnek tekintjük
                if float(alt_val) < 50: return False
            except: pass
            return True

        for _, row in df.iterrows():
            currently_air = check_is_air(row['alt'])

            # Letisztított pont az útvonalhoz (metaadatok nélkül, hogy ne foglalja a helyet)
            clean_point = {
                'ts': row['ts'],
                'lat': row['lat'],
                'lon': row['lon'],
                'alt': row['alt'],
                'spd': row['spd']
            }

            if not is_in_air and currently_air:
                # Felszállás (Ground -> Air)
                is_in_air = True
                current_flight_points = [clean_point]

            elif is_in_air and currently_air:
                # Repülés (Air -> Air)
                current_flight_points.append(clean_point)

            elif is_in_air and not currently_air:
                # Leszállás (Air -> Ground) - ITT A VÉGE EGY REPÜLÉSNEK
                is_in_air = False
                current_flight_points.append(clean_point)
                self.save_flight(current_flight_points, meta)
                current_flight_points = []

        # Ha az adatsor végén még levegőben van (pl. hiányos adat)
        if is_in_air and current_flight_points:
            self.save_flight(current_flight_points, meta, incomplete=True)

    def save_flight(self, flight_points, meta, incomplete=False):
        """
        Itt választjuk ketté:
        1. JSON-be megy a teljes adat.
        2. Táblázatba (CSV) csak az összefoglaló.
        """
        if len(flight_points) < 5: return # Zajszűrés

        start_pt = flight_points[0]
        end_pt = flight_points[-1]

        start_dt = datetime.fromtimestamp(start_pt['ts'])
        end_dt = datetime.fromtimestamp(end_pt['ts'])
        duration = round((end_pt['ts'] - start_pt['ts']) / 60, 1) # percben

        # 1. Az ÖSSZEFOGLALÓ adat (Route nélkül)
        summary_record = {
            'Aircraft_ID': meta['id'],
            'Registration': meta['reg'],
            'Type': meta['type'],
            'Operator': meta['op'],
            'Date': start_dt.strftime('%Y-%m-%d'),
            'Start_Time': start_dt.strftime('%H:%M:%S'),
            'End_Time': end_dt.strftime('%H:%M:%S'),
            'Duration_Min': duration,
            'Start_Lat': start_pt['lat'],
            'Start_Lon': start_pt['lon'],
            'End_Lat': end_pt['lat'],
            'End_Lon': end_pt['lon'],
            'Status': 'Incomplete' if incomplete else 'Landed'
        }
        self.summary_flights.append(summary_record)

        # 2. A RÉSZLETES adat (Route-tal együtt) - Ez megy a JSON-be
        # A summary rekordot kiegészítjük a route listával
        detailed_record = summary_record.copy()
        detailed_record['Route'] = flight_points

        self.detailed_flights.append(detailed_record)

    def export_data(self, result_path):
        """Kimenti a kétféle fájlt."""

        # 1. RÉSZLETES JSON mentése
        if self.detailed_flights:
            json_filename = 'repulesek_RESZLETES.json'
            json_filename = os.path.join(result_path, json_filename)
            with open(json_filename, 'w', encoding='utf-8') as f:
                json.dump(self.detailed_flights, f, indent=None) # indent=None a kisebb fájlméretért, vagy 4 a szépségért
            print(f"Részletes JSON mentve: {json_filename}")

        # 2. ÖSSZEFOGLALÓ TÁBLÁZAT (CSV) mentése
        if self.summary_flights:
            csv_filename = 'repulesek_TABLAZAT.csv'
            csv_filename = os.path.join(result_path, csv_filename)
            df_summary = pd.DataFrame(self.summary_flights)
            df_summary.to_csv(csv_filename, index=False)
            print(f"Összefoglaló táblázat mentve: {csv_filename}")

# --- Futtatás ---
if __name__ == "__main__":
    all_data = pd.DataFrame()

    # list folders in /home/misi/nerlines/
    folders = [f for f in os.listdir('/home/misi/nerlines/data/') if os.path.isdir(os.path.join('/home/misi/nerlines/data/', f))]
    print("Available folders in /home/misi/nerlines/:")
    for folder in folders:
        print(f"  {folder}")

        processor = FlightProcessor(input_folder=f'/home/misi/nerlines/data/{folder}')

        processor.process_all()
        df = pd.DataFrame(processor.summary_flights)
        df["plane_id"] = folder
        df.to_csv(f'/home/misi/nerlines/results/summary_{folder}.csv', index=False)
        all_data = pd.concat([all_data, df], ignore_index=True)
    all_data.to_csv('/home/misi/nerlines/results/summary_all.csv', index=False)
    print("Összesített összefoglaló táblázat mentve: /home/misi/nerlines/results/summary_all.csv")



        